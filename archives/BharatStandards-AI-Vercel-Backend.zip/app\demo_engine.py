from __future__ import annotations

import re
from typing import Any

# DEMO records are deliberately small and explicit. A standard can only be
# recommended when the current procurement case resolves to the same canonical
# product family. Shared materials (PVC, steel, copper, etc.) never establish
# product identity.
DEMO_CASES: list[dict[str, Any]] = [
    {
        "caseId": "ceilingFan",
        "productFamily": "CEILING_FAN",
        "identityAliases": ["ceiling fan", "ceiling fans", "electric ceiling fan", "fan"],
        "categories": ["electrical appliances", "fans", "fan"],
        "subcategories": ["ceiling fan", "fans"],
        "applications": ["air circulation", "indoor", "classroom", "school"],
        "materials": [],
        "standard": {
            "standardId": "IS-374-2019",
            "isNumber": "IS 374 : 2019",
            "title": "Electric ceiling type fans and regulators — Specification",
            "category": "Electrical Appliances",
            "status": "ACTIVE",
            "confidenceBase": 82,
            "evidenceTerms": ["ceiling fan", "fan", "air circulation", "1200 mm", "230 v", "50 hz"],
        },
        "relationships": [
            {"standard": "IS 302-2-80 : 2017", "title": "Safety of household electrical appliances — Particular requirements for fans", "relationship": "SAFETY", "applicability": "Applicable", "mandatory": "Needs Review", "reason": "Electrical safety requirements", "status": "ACTIVE"},
            {"standard": "IS 6873 : 2019", "title": "Limits and methods of measurement of radio disturbance", "relationship": "TEST_METHOD", "applicability": "Applicable", "mandatory": "No", "reason": "EMC testing where applicable", "status": "ACTIVE"},
        ],
        "version": {"currentVersion": "IS 374 : 2019", "status": "Latest", "reaffirmed": "2024", "supersedes": None, "supersededBy": None, "amendments": []},
        # Demo regulatory records marked Needs Review cannot establish legal mandatory status.
        "certifications": [{"type": "BIS Product Certification", "mandatory": None, "scheme": "Scheme-I", "status": "Needs Review", "sourceVerified": False}],
        "qcos": [{"name": "Electric Fans (Quality Control) Order, 2024", "status": "Needs Review", "effectiveDate": "05 Mar 2025", "sourceVerified": False}],
    },
    {
        "caseId": "structuralSteel",
        "productFamily": "STRUCTURAL_STEEL_PLATE",
        "identityAliases": ["structural steel", "steel plate", "steel plates", "structural steel plate", "structural steel plates", "hot rolled steel"],
        "categories": ["materials & structural", "structural steel", "steel"],
        "subcategories": ["steel plate", "structural steel plate"],
        "applications": ["structural", "bridge", "fabrication"],
        "materials": ["steel", "hot rolled steel"],
        "standard": {
            "standardId": "IS-2062-2011",
            "isNumber": "IS 2062 : 2011",
            "title": "Hot rolled medium and high tensile structural steel",
            "category": "Materials & Structural",
            "status": "ACTIVE",
            "confidenceBase": 84,
            "evidenceTerms": ["structural steel", "steel plate", "steel plates", "hot rolled", "250 mpa", "yield strength", "weldability"],
        },
        "relationships": [
            {"standard": "IS 1608 (Part 1) : 2022", "title": "Metallic materials — Tensile testing", "relationship": "TEST_METHOD", "applicability": "Applicable", "mandatory": "No", "reason": "Tensile property verification", "status": "ACTIVE"},
            {"standard": "IS 228 (Series)", "title": "Methods of chemical analysis of steels", "relationship": "TEST_METHOD", "applicability": "Applicable", "mandatory": "No", "reason": "Chemical composition verification", "status": "ACTIVE"},
        ],
        "version": {"currentVersion": "IS 2062 : 2011", "status": "Needs Review", "reaffirmed": None, "supersedes": None, "supersededBy": None, "amendments": ["Amendment No. 2 — demo registry"]},
        "certifications": [{"type": "BIS Product Certification", "mandatory": None, "scheme": "Scheme-I", "status": "Needs Review", "sourceVerified": False}],
        "qcos": [],
    },
    {
        "caseId": "electricalCable",
        "productFamily": "ELECTRICAL_CABLE",
        "identityAliases": ["pvc insulated cable", "pvc insulated cables", "electrical cable", "electrical cables", "electric cable", "cable", "cables", "building wire"],
        "categories": ["electrical", "electrical cable", "cables"],
        "subcategories": ["pvc insulated cable", "cable"],
        "applications": ["wiring", "electrical installation"],
        "materials": ["pvc", "copper", "aluminium"],
        "standard": {
            "standardId": "IS-694-2010",
            "isNumber": "IS 694 : 2010",
            "title": "PVC insulated cables for working voltages up to and including 1100 V",
            "category": "Electrical",
            "status": "REVISED",
            "confidenceBase": 84,
            "evidenceTerms": ["pvc insulated", "electrical cable", "cable", "cables", "1100 v", "conductor", "insulation"],
        },
        "relationships": [
            {"standard": "IS 10810 (Series)", "title": "Methods of test for cables", "relationship": "TEST_METHOD", "applicability": "Applicable", "mandatory": "No", "reason": "Cable testing methods", "status": "Needs Review"},
        ],
        "version": {"currentVersion": "IS 694 : 2010", "status": "Needs Review", "reaffirmed": None, "supersedes": None, "supersededBy": None, "amendments": []},
        "certifications": [{"type": "BIS Product Certification", "mandatory": None, "scheme": "Scheme-I", "status": "Needs Review", "sourceVerified": False}],
        "qcos": [],
    },
    {
        "caseId": "waterTank",
        "productFamily": "WATER_TANK",
        "identityAliases": ["water storage tank", "water tank", "polyethylene water tank", "rotomoulded water tank", "rotational moulded water tank"],
        "categories": ["water storage", "plastic products", "civil engineering", "tank"],
        "subcategories": ["water tank", "polyethylene tank"],
        "applications": ["water storage", "potable water storage"],
        "materials": ["polyethylene", "plastic"],
        "standard": {
            "standardId": "IS-12701",
            "isNumber": "IS 12701",
            "title": "Rotational moulded polyethylene water storage tanks — Specification",
            "category": "Water Storage",
            "status": "NEEDS_REVIEW",
            "confidenceBase": 82,
            "evidenceTerms": ["water storage tank", "water tank", "polyethylene", "potable water", "capacity", "rotomoulded"],
        },
        "relationships": [],
        "version": {"currentVersion": "IS 12701", "status": "Needs Review", "reaffirmed": None, "supersedes": None, "supersededBy": None, "amendments": []},
        "certifications": [],
        "qcos": [],
    },
]

MATERIAL_TERMS = {"pvc", "steel", "copper", "plastic", "aluminium", "aluminum", "polyethylene"}


def _flatten(value: Any) -> str:
    if isinstance(value, dict):
        return " ".join(_flatten(v) for v in value.values())
    if isinstance(value, list):
        return " ".join(_flatten(v) for v in value)
    return "" if value is None else str(value)


def _norm(text: Any) -> str:
    value = str(text or "").lower()
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def _contains_phrase(text: str, phrase: str) -> bool:
    """Exact normalized token/phrase containment; never raw substring matching."""
    t = _norm(text)
    p = _norm(phrase)
    if not p:
        return False
    return re.search(rf"(?:^|\s){re.escape(p)}(?:$|\s)", t) is not None


def _profile_text(requirement_profile: dict[str, Any]) -> str:
    return _norm(_flatten(requirement_profile))


def _identity_text(requirement_profile: dict[str, Any], original_text: str) -> str:
    product = requirement_profile.get("product") or {}
    parts = [product.get("name", ""), product.get("category", ""), product.get("subcategory", "")]
    # The current input is allowed as a second source for identity recovery when the model
    # uses a terse category label.
    parts.append(original_text)
    return _norm(" ".join(str(x or "") for x in parts))


def resolve_product_family(requirement_profile: dict[str, Any], original_text: str) -> str | None:
    """Resolve the current case to one canonical product family.

    Order matters: pipe is checked before cable so shared material terms such as PVC
    cannot make a pipe look like a cable. Material-only matches are intentionally ignored.
    """
    identity = _identity_text(requirement_profile, original_text)

    pipe_identity = any(_contains_phrase(identity, p) for p in ["pipe", "pipes", "water pipe", "pvc pipe", "upvc pipe", "unplasticized pvc pipe"])
    pvc_context = any(_contains_phrase(identity, p) for p in ["pvc", "upvc", "unplasticized pvc", "potable water"])
    if pipe_identity and pvc_context:
        return "PVC_WATER_PIPE"

    if any(_contains_phrase(identity, p) for p in ["structural steel plate", "structural steel plates", "steel plate", "steel plates", "structural steel"]):
        return "STRUCTURAL_STEEL_PLATE"
    if any(_contains_phrase(identity, p) for p in ["ceiling fan", "ceiling fans", "electric ceiling fan"]):
        return "CEILING_FAN"
    if any(_contains_phrase(identity, p) for p in ["electrical cable", "electrical cables", "electric cable", "pvc insulated cable", "pvc insulated cables", "building wire", "cable", "cables"]):
        return "ELECTRICAL_CABLE"
    if any(_contains_phrase(identity, p) for p in ["water storage tank", "water tank", "polyethylene water tank", "rotomoulded water tank", "rotational moulded water tank"]):
        return "WATER_TANK"
    return None


def _matched_evidence(case: dict[str, Any], requirement_profile: dict[str, Any], original_text: str) -> list[dict[str, str]]:
    profile_text = _profile_text(requirement_profile)
    matches: list[dict[str, str]] = []
    seen: set[str] = set()
    for term in case["standard"].get("evidenceTerms", []):
        key = _norm(term)
        if not key or key in seen or key in MATERIAL_TERMS:
            continue
        if _contains_phrase(original_text, term):
            matches.append({"text": term, "source": "INPUT_TEXT"})
            seen.add(key)
        elif _contains_phrase(profile_text, term):
            matches.append({"text": term, "source": "REQUIREMENT_PROFILE"})
            seen.add(key)
    return matches


def recommend_demo_standards(
    requirement_profile: dict[str, Any], original_text: str
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], str | None]:
    """Strict DEMO retrieval.

    Returns (accepted candidates, diagnostics for every candidate, current product family).
    Rejected candidates are never scored and can never become primaryStandard.
    """
    family = resolve_product_family(requirement_profile, original_text)
    profile_text = _profile_text(requirement_profile)
    candidates: list[dict[str, Any]] = []
    diagnostics: list[dict[str, Any]] = []

    for case in DEMO_CASES:
        standard = case["standard"]
        candidate_family = case["productFamily"]
        product_compatible = family is not None and family == candidate_family
        diagnostic: dict[str, Any] = {
            "standardId": standard["standardId"],
            "requirementProductFamily": family,
            "candidateProductFamily": candidate_family,
            "productCompatible": product_compatible,
            "categoryCompatible": False,
            "scopeCompatible": False,
            "matchedTerms": [],
            "rejectedTerms": [],
            "rejectReason": None,
            "rawScore": None,
            "finalScore": None,
        }
        if not product_compatible:
            diagnostic["rejectReason"] = "PRODUCT_FAMILY_MISMATCH" if family else "PRODUCT_FAMILY_UNRESOLVED"
            diagnostics.append(diagnostic)
            continue

        product = requirement_profile.get("product") or {}
        category_text = _norm(f"{product.get('category', '')} {product.get('subcategory', '')}")
        application_text = _norm(_flatten(requirement_profile.get("application") or {}))
        # Family equality is the hard identity rule. Category/application are supporting
        # checks; missing AI fields do not falsely reject an otherwise exact family.
        category_compatible = not category_text or any(_contains_phrase(category_text, x) for x in case.get("categories", []) + case.get("subcategories", []))
        application_compatible = not application_text or not case.get("applications") or any(_contains_phrase(application_text, x) for x in case.get("applications", []))
        diagnostic["categoryCompatible"] = category_compatible
        diagnostic["scopeCompatible"] = application_compatible

        if not category_compatible:
            diagnostic["rejectReason"] = "CATEGORY_MISMATCH"
            diagnostics.append(diagnostic)
            continue

        # Scope/application may be absent or expressed differently; it contributes to
        # score but cannot override a product-family mismatch.
        evidence = _matched_evidence(case, requirement_profile, original_text)
        matched_terms = [item["text"] for item in evidence]
        diagnostic["matchedTerms"] = matched_terms
        base = int(standard.get("confidenceBase", 75))
        raw_score = base + min(9, len(matched_terms) * 3) + (3 if application_compatible else 0)
        score = min(97, raw_score)
        diagnostic["rawScore"] = raw_score
        diagnostic["finalScore"] = score
        diagnostics.append(diagnostic)

        candidates.append({
            "standardId": standard["standardId"],
            "isNumber": standard["isNumber"],
            "title": standard["title"],
            "category": standard["category"],
            "status": standard["status"],
            "confidence": score,
            "certification": case["certifications"][0]["type"] if case["certifications"] else "Needs Review",
            "matchedEvidence": evidence,
            "dataMode": "DEMO",
            "caseId": case["caseId"],
            "productFamily": candidate_family,
        })

    candidates.sort(key=lambda item: item["confidence"], reverse=True)
    return candidates[:5], diagnostics, family


def expand_demo_case(primary_standard_id: str | None) -> dict[str, Any]:
    if not primary_standard_id:
        return {"alliedStandards": [], "versionChecks": [], "certifications": [], "qcos": []}
    for case in DEMO_CASES:
        if case["standard"]["standardId"] == primary_standard_id:
            return {
                "alliedStandards": list(case["relationships"]),
                "versionChecks": [dict(case["version"])],
                "certifications": list(case["certifications"]),
                "qcos": list(case["qcos"]),
            }
    return {"alliedStandards": [], "versionChecks": [], "certifications": [], "qcos": []}
