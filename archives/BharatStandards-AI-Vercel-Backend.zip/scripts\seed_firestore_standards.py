from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

import inspect
import re
from typing import Any

from app import demo_engine
from app.firebase_service import get_firestore_client


def is_standard_record(value: Any) -> bool:
    """
    Detect a standard record already defined inside demo_engine.py.

    We deliberately require standardId so random configuration
    dictionaries are not uploaded.
    """
    if not isinstance(value, dict):
        return False

    standard_id = value.get("standardId")

    if not isinstance(standard_id, str) or not standard_id.strip():
        return False

    # A standard record should normally contain at least one of these.
    standard_fields = {
        "title",
        "productFamily",
        "category",
        "scope",
        "keywords",
        "applications",
        "description",
    }

    return bool(standard_fields.intersection(value.keys()))


def walk(value: Any, results: list[dict], visited: set[int]) -> None:
    """
    Recursively search constants/collections defined in demo_engine.py.
    """
    value_id = id(value)

    if value_id in visited:
        return

    visited.add(value_id)

    if is_standard_record(value):
        results.append(dict(value))
        return

    if isinstance(value, dict):
        for child in value.values():
            walk(child, results, visited)

    elif isinstance(value, (list, tuple, set)):
        for child in value:
            walk(child, results, visited)


def discover_demo_standards() -> list[dict]:
    records: list[dict] = []
    visited: set[int] = set()

    for name, value in vars(demo_engine).items():
        # Ignore imported modules, functions, classes and private names.
        if name.startswith("_"):
            continue

        if inspect.ismodule(value):
            continue

        if inspect.isfunction(value):
            continue

        if inspect.isclass(value):
            continue

        walk(value, records, visited)

    # Deduplicate using standardId.
    unique: dict[str, dict] = {}

    for record in records:
        standard_id = record["standardId"].strip()

        if standard_id not in unique:
            unique[standard_id] = record
        else:
            # Prefer the more detailed record if duplicate objects exist.
            if len(record) > len(unique[standard_id]):
                unique[standard_id] = record

    return list(unique.values())


def make_document_id(standard_id: str) -> str:
    value = standard_id.strip()

    # Firestore document IDs cannot contain "/".
    value = value.replace("/", "_")

    # Make IDs easier to read.
    value = re.sub(r"\s+", "_", value)

    return value


def main() -> None:
    print()
    print("BharatStandards AI")
    print("Demo Engine -> Firestore migration")
    print("=" * 55)

    standards = discover_demo_standards()

    if not standards:
        raise RuntimeError(
            "No standard records containing standardId were discovered "
            "inside app/demo_engine.py."
        )

    print(f"\nDiscovered {len(standards)} standards:\n")

    for standard in standards:
        print(
            f"  {standard.get('standardId')} | "
            f"{standard.get('title', 'No title')} | "
            f"{standard.get('productFamily', 'No family')}"
        )

    print("\nConnecting to Firestore...")

    db = get_firestore_client()

    collection = db.collection("standards")

    uploaded = 0

    for standard in standards:
        standard_id = standard["standardId"].strip()
        document_id = make_document_id(standard_id)

        # merge=False is intentional:
        # Firestore receives the exact current demo record rather
        # than preserving old fields from an earlier document.
        collection.document(document_id).set(
            standard,
            merge=False,
        )

        uploaded += 1
        print(f"Uploaded: {standard_id} -> standards/{document_id}")

    print()
    print("=" * 55)
    print(f"Migration complete.")
    print(f"Standards discovered : {len(standards)}")
    print(f"Standards uploaded   : {uploaded}")
    print("Firestore collection : standards")
    print("=" * 55)


if __name__ == "__main__":
    main()