from __future__ import annotations

from .firebase_service import get_firestore_client


def get_all_standards() -> list[dict]:
    db = get_firestore_client()

    standards = []

    for doc in db.collection("standards").stream():
        data = doc.to_dict() or {}
        data.setdefault("documentId", doc.id)
        standards.append(data)

    return standards


def get_standard_by_id(standard_id: str) -> dict | None:
    db = get_firestore_client()

    query = (
        db.collection("standards")
        .where("standardId", "==", standard_id)
        .limit(1)
        .stream()
    )

    for doc in query:
        data = doc.to_dict() or {}
        data.setdefault("documentId", doc.id)
        return data

    return None