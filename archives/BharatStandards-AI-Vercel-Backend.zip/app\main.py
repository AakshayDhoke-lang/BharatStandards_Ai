from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone

from dotenv import load_dotenv
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .demo_engine import expand_demo_case, recommend_demo_standards
from .document_processing import parse_document_bytes
from .nvidia_service import (
    extract_requirement_profile,
    get_base_url,
    get_provider,
    is_vercel_runtime,
    list_lm_studio_models,
    set_provider,
    test_ai_connection,
)
from .firebase_service import firebase_admin_configured, firestore_health

load_dotenv()
app = FastAPI(title="BharatStandards AI API", version="0.4.0")
@app.get("/api")
def api_root():
    return {
        "ok": True,
        "service": "bharatstandards-ai-api"
    }
default_origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "https://bharatstandards-ai.web.app",
    "https://bharatstandards-ai.firebaseapp.com",
]
extra_origins = [origin.strip() for origin in os.getenv("CORS_ORIGINS", "").split(",") if origin.strip()]
allowed_origins = list(dict.fromkeys(default_origins + extra_origins))

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    provider = get_provider()
    return {
        "status": "ok",
        "service": "bharatstandards-ai-api",
        "documentParser": "lightweight",
        "parsers": ["PyMuPDF", "python-docx", "openpyxl", "python-pptx", "native text/csv/html"],
        "aiProvider": provider,
        "aiBaseUrl": get_base_url(provider),
        "nvidiaConfigured": bool(os.getenv("NVIDIA_API_KEY")),
        "lmStudioBaseUrl": get_base_url("lmstudio"),
        "dataMode": "DEMO" if os.getenv("DEMO_MODE", "false").lower() == "true" else "REAL",
        "runtime": "vercel" if is_vercel_runtime() else "local",
        "firestoreAdminConfigured": firebase_admin_configured(),
    }




@app.get("/api/firestore/health")
def firestore_connection_health():
    result = firestore_health()
    if not result.get("ok"):
        raise HTTPException(status_code=503, detail=result)
    return result


@app.get("/api/ai/test")
async def ai_test():
    try:
        return await test_ai_connection()
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get("/api/ai/lmstudio/models")
async def lmstudio_models():
    try:
        models = await list_lm_studio_models()
        return {"ok": True, "baseUrl": get_base_url("lmstudio"), "models": models, "activeModel": models[0]}
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


class ProviderSelection(BaseModel):
    provider: str


@app.get("/api/ai/provider")
def ai_provider():
    return {"provider": get_provider(), "baseUrl": get_base_url()}


@app.post("/api/ai/provider")
def ai_provider_update(payload: ProviderSelection):
    try:
        provider = set_provider(payload.provider)
        return {"ok": True, "provider": provider, "baseUrl": get_base_url(provider)}
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/documents/parse")
async def parse_document(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="A file name is required.")
    content = await file.read()
    if len(content) > 50 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Maximum upload size is 50 MB.")
    try:
        return parse_document_bytes(file.filename, content)
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Document parsing failed: {type(exc).__name__}: {exc}") from exc


class RequirementText(BaseModel):
    text: str
    source_name: str | None = None
    language: str = "en"
    demo_mode: bool | None = None
    input_type: str = "TEXT"


@app.post("/api/ai/requirement-profile")
async def requirement_profile(payload: RequirementText):
    if not payload.text.strip():
        raise HTTPException(status_code=400, detail="Text is required.")
    try:
        profile, ai_meta = await extract_requirement_profile(payload.text, payload.language)
        return {
            "requirementProfile": profile,
            "provider": ai_meta["provider"],
            "model": ai_meta["model"],
            "inputCharacters": len(payload.text),
            "sourceName": payload.source_name,
        }
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post("/api/analysis/run")
async def run_analysis(payload: RequirementText):
    text = payload.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Extracted procurement text is empty.")
    try:
        profile, ai_meta = await extract_requirement_profile(text, payload.language)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    demo_mode = payload.demo_mode if payload.demo_mode is not None else os.getenv("DEMO_MODE", "false").lower() == "true"
    if demo_mode:
        recommendations, candidate_diagnostics, canonical_product_family = recommend_demo_standards(profile, text)
    else:
        recommendations, candidate_diagnostics, canonical_product_family = [], [], None
    primary = recommendations[0] if recommendations else None
    expanded = expand_demo_case(primary.get("standardId") if primary else None) if demo_mode else {"alliedStandards": [], "versionChecks": [], "certifications": [], "qcos": []}
    analysis_id = f"ANL-{uuid.uuid4().hex[:8].upper()}"
    input_id = f"INP-{uuid.uuid4().hex[:8].upper()}"

    # Evidence is deliberately scoped to this request only. No prior analysis state is consulted.
    evidence = [{
        "analysisId": analysis_id,
        "inputId": input_id,
        "sourceType": "Uploaded tender" if payload.input_type.upper() == "FILE" else "User-entered description",
        "text": text[:1200],
        "requirementKey": "current_input",
    }]

    # Requirement presence and standard coverage are different concepts.
    # The requirement profile proves only that a tender requirement is present.
    # This demo build does not contain clause-level coverage assertions, therefore
    # standardCoverage remains UNKNOWN (or NOT_EVALUATED when there is no primary).
    coverage = []
    for key in ("product", "application", "materials", "dimensions", "technicalProperties", "performance", "safety", "testing", "certification"):
        value = profile.get(key)
        if value not in (None, "", [], {}):
            coverage.append({
                "requirement": key,
                "tenderPresent": True,
                "evidence": "Current requirement profile",
                "standardCoverage": "UNKNOWN" if primary else "NOT_EVALUATED",
            })

    warnings: list[dict[str, str]] = []
    if not recommendations:
        warnings.append({
            "code": "NO_COMPATIBLE_DEMO_STANDARD" if demo_mode else "REAL_DATASET_NOT_CONFIGURED",
            "severity": "WARNING",
            "message": "No product-compatible standard exists in the active demo dataset." if demo_mode else "DEMO mode is disabled and no verified REAL dataset is configured yet.",
        })
    if primary and not expanded["alliedStandards"]:
        warnings.append({"code": "NO_ALLIED_STANDARD_RECORD", "severity": "WARNING", "message": "No verified allied standards are available for this standard in the current knowledge base."})
    if primary and not expanded["certifications"]:
        warnings.append({"code": "NO_CERTIFICATION_RECORD", "severity": "WARNING", "message": "No verified certification/QCO record was found for the current product in the active knowledge base."})

    certification_requested = bool((profile.get("certification") or {}).get("requested"))
    certification_summary = {
        "tenderRequestsCertificationEvidence": certification_requested,
        "certificationMandatory": expanded["certifications"][0].get("mandatory") if expanded["certifications"] else None,
        "status": expanded["certifications"][0].get("status", "NEEDS_REVIEW") if expanded["certifications"] else "NEEDS_REVIEW",
    }

    return {
        "analysisId": analysis_id,
        "inputId": input_id,
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "sourceName": payload.source_name,
        "provider": ai_meta["provider"],
        "model": ai_meta["model"],
        "dataMode": "DEMO" if demo_mode else "REAL",
        "input": {"type": payload.input_type.upper(), "inputId": input_id},
        "requirementProfile": profile,
        "canonicalProductFamily": canonical_product_family,
        "candidateDiagnostics": candidate_diagnostics,
        "candidateStandards": recommendations,
        "recommendations": recommendations,
        "primaryStandard": primary,
        "alliedStandards": expanded["alliedStandards"],
        "versionChecks": expanded["versionChecks"],
        "certifications": expanded["certifications"],
        "qcos": expanded["qcos"],
        "certificationSummary": certification_summary,
        "coverage": coverage,
        "missingRequirements": [],
        "evidence": evidence,
        "warnings": warnings,
        "confidence": {"overall": primary.get("confidence") if primary else None},
        "status": "DEMO" if demo_mode and primary else "NEEDS_REVIEW",
        "pipeline": [
            {"stage": "INPUT_TEXT", "status": "PASS", "characters": len(text)},
            {"stage": "AI_REQUIREMENT_EXTRACTION", "status": "PASS", "provider": ai_meta["provider"], "model": ai_meta["model"], "latencyMs": ai_meta["latencyMs"]},
            {"stage": "PRODUCT_COMPATIBILITY_FILTER", "status": "PASS" if recommendations else "NO_MATCH", "candidates": len(recommendations), "productFamily": canonical_product_family},
            {"stage": "DEMO_STANDARD_MATCHING" if demo_mode else "REAL_DATASET_RETRIEVAL", "status": ("PASS" if recommendations else "NO_MATCH") if demo_mode else "SKIPPED", "candidates": len(recommendations)},
        ],
    }
