from __future__ import annotations

import argparse
import json
import os
import re
import sys
from collections import Counter
from functools import lru_cache
from pathlib import Path
from typing import Any

from demo_database_validation import COLLECTIONS, load_database, validate_database

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "complete_demo_database.json"
TARGET_DATASET = "demo"


def _clean_private_key(value: str) -> str:
    return value.replace("\\n", "\n").strip()


def _service_account_from_env() -> dict[str, Any] | None:
    raw = os.getenv("FIREBASE_SERVICE_ACCOUNT_JSON", "").strip()
    if raw:
        data = json.loads(raw)
        if data.get("private_key"):
            data["private_key"] = _clean_private_key(str(data["private_key"]))
        return data
    project_id = os.getenv("FIREBASE_PROJECT_ID", "").strip()
    client_email = os.getenv("FIREBASE_CLIENT_EMAIL", "").strip()
    private_key = os.getenv("FIREBASE_PRIVATE_KEY", "").strip()
    if project_id and client_email and private_key:
        return {
            "type": "service_account", "project_id": project_id,
            "private_key": _clean_private_key(private_key), "client_email": client_email,
            "token_uri": "https://oauth2.googleapis.com/token",
        }
    return None


@lru_cache(maxsize=1)
def get_firestore_client():
    try:
        import firebase_admin
        from firebase_admin import credentials, firestore
    except ImportError as exc:
        raise RuntimeError("firebase-admin is not installed. Run: python -m pip install firebase-admin") from exc
    if not firebase_admin._apps:
        env_credential = _service_account_from_env()
        if env_credential:
            firebase_admin.initialize_app(credentials.Certificate(env_credential))
        else:
            path = os.getenv("FIREBASE_SERVICE_ACCOUNT_PATH", "").strip()
            if path:
                firebase_admin.initialize_app(credentials.Certificate(path))
            else:
                firebase_admin.initialize_app()
    return firestore.client()


def firebase_project_id(db: Any) -> str:
    project = getattr(db, "project", None)
    if project:
        return str(project)
    try:
        return str(db._client.project)
    except Exception:
        return os.getenv("FIREBASE_PROJECT_ID", "unknown")


def slug(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip())
    return value.strip("-_") or "record"


def doc_id(collection_name: str, record: dict[str, Any], index: int) -> str:
    keys = {
        "categories": ["categoryId", "name"], "products": ["productId", "productFamily", "productName"],
        "standards": ["standardId", "isNumber"], "relationships": ["relationshipId"],
        "certifications": ["certificationId"], "qcos": ["qcoId"],
        "amendments": ["versionRecordId", "standardId"], "sources": ["sourceId", "sourceName"],
        "submissions": ["submissionId"], "ingestionJobs": ["jobId"], "auditLogs": ["entityId", "action"],
    }
    for key in keys[collection_name]:
        value = record.get(key)
        if value:
            if collection_name == "auditLogs" and key == "entityId":
                return slug(f"demo-audit-{index:03d}-{record.get('action', 'event')}-{value}")
            return slug(str(value))
    return f"demo-{collection_name}-{index:03d}"


def expected_docs(payload: dict[str, Any]) -> dict[str, dict[str, dict[str, Any]]]:
    out: dict[str, dict[str, dict[str, Any]]] = {}
    for name in COLLECTIONS:
        docs: dict[str, dict[str, Any]] = {}
        for idx, source in enumerate(payload.get(name, []), 1):
            rec = dict(source)
            rec.setdefault("dataMode", "DEMO")
            rec.setdefault("datasetMode", "DEMO")
            rec.setdefault("seedVersion", payload["meta"]["seedVersion"])
            docs[doc_id(name, rec, idx)] = rec
        out[name] = docs
    return out


def validate_or_exit(payload: dict[str, Any]) -> dict[str, Any]:
    report = validate_database(payload)
    print("Validation:", "PASS" if report["ok"] else "FAIL")
    for name in COLLECTIONS:
        print(f"  {name:<16} {report['counts'][name]:>4}")
    if report["warnings"]:
        print("Warnings:")
        for w in report["warnings"]:
            print("  -", w)
    if not report["ok"]:
        print("Critical validation failures:")
        for e in report["errors"]:
            print("  -", e)
        raise SystemExit(2)
    return report


def firestore_snapshot(db: Any, expected: dict[str, dict[str, dict[str, Any]]]) -> tuple[dict[str, dict[str, dict[str, Any]]], dict[str, list[str]]]:
    dataset = db.collection("datasets").document(TARGET_DATASET)
    actual: dict[str, dict[str, dict[str, Any]]] = {}
    stale: dict[str, list[str]] = {}
    for name in COLLECTIONS:
        docs = {snap.id: (snap.to_dict() or {}) for snap in dataset.collection(name).stream()}
        actual[name] = docs
        stale[name] = sorted(set(docs) - set(expected[name]))
    return actual, stale


def plan_changes(expected: dict[str, dict[str, dict[str, Any]]], actual: dict[str, dict[str, dict[str, Any]]]) -> Counter:
    c: Counter = Counter()
    for name in COLLECTIONS:
        for rid, record in expected[name].items():
            if rid not in actual[name]:
                c["CREATE"] += 1
            elif actual[name][rid] == record:
                c["UNCHANGED"] += 1
            else:
                c["UPDATE"] += 1
    return c


def verify_after_seed(db: Any, payload: dict[str, Any]) -> bool:
    from demo_database_validation import CRITICAL_MAPPINGS
    expected = expected_docs(payload)
    actual, stale = firestore_snapshot(db, expected)
    ok = True
    print("\nPost-seed Firestore verification")
    print("-" * 42)
    for name in COLLECTIONS:
        got = len(actual[name]); want = len(expected[name])
        state = "PASS" if got == want else "FAIL"
        print(f"{name:<16} {got:>4} / {want:<4} {state}")
        if got != want: ok = False
    products = actual["products"]
    print("\nCritical mappings:")
    for pid, (family, sid) in CRITICAL_MAPPINGS.items():
        rec = products.get(pid, {})
        passed = rec.get("productFamily") == family and rec.get("primaryStandardId") == sid
        print(f"  [{'PASS' if passed else 'FAIL'}] {pid}: {rec.get('productFamily')} -> {rec.get('primaryStandardId')}")
        ok = ok and passed
    stale_count = sum(len(v) for v in stale.values())
    if stale_count:
        print(f"\nSTALE DEMO documents remaining: {stale_count}")
        for name, ids in stale.items():
            for rid in ids: print(f"  STALE datasets/demo/{name}/{rid}")
    return ok


def seed(args: argparse.Namespace) -> None:
    if args.dataset.lower() != TARGET_DATASET:
        raise SystemExit("REFUSED: this seeder may target only datasets/demo.")
    payload = load_database(DATA_FILE)
    print("BharatStandards AI")
    print("DEMO Firestore Seeder")
    print("=" * 44)
    print("Target Dataset: datasets/demo")
    print("REAL DATA: PROTECTED")
    print("User Analyses: PROTECTED")
    print(f"Seed version: {payload['meta']['seedVersion']}")
    validate_or_exit(payload)
    if args.validate_only:
        print("\nValidation-only complete. No Firestore connection or writes were made.")
        return

    db = get_firestore_client()
    project = firebase_project_id(db)
    print(f"\nFirebase Project: {project}")
    expected = expected_docs(payload)
    actual, stale = firestore_snapshot(db, expected)
    changes = plan_changes(expected, actual)
    stale_count = sum(len(v) for v in stale.values())
    print("\nSynchronization plan:")
    for key in ("CREATE", "UPDATE", "UNCHANGED"):
        print(f"  {key:<10} {changes[key]}")
    print(f"  STALE      {stale_count}")
    for name, ids in stale.items():
        for rid in ids: print(f"  STALE: datasets/demo/{name}/{rid}")

    if args.dry_run:
        print("  DELETE     0")
        print("\nDry run complete. No Firestore writes or deletes were made.")
        return
    if args.delete_stale and args.mode != "sync":
        raise SystemExit("--delete-stale requires --mode sync")
    if not args.yes:
        answer = input("\nType DEMO to confirm writing only datasets/demo: ").strip()
        if answer != "DEMO":
            raise SystemExit("Cancelled. No writes made.")

    dataset_ref = db.collection("datasets").document(TARGET_DATASET)
    dataset_ref.set({**payload["meta"], "datasetMode": "DEMO", "dataMode": "DEMO", "active": True}, merge=True)
    # Operational metadata; not regulatory evidence.
    dataset_ref.collection("metadata").document("database").set({
        "schemaVersion": payload["meta"].get("schemaVersion"),
        "datasetVersion": payload["meta"].get("datasetVersion", payload["meta"].get("seedVersion")),
        "recordCounts": payload["meta"].get("recordCounts", payload["meta"].get("counts", {})),
        "generatedAt": payload["meta"].get("generatedAt"), "dataMode": "DEMO",
    }, merge=True)

    stats: Counter = Counter()
    batch = db.batch(); queued = 0
    for name in COLLECTIONS:
        for rid, rec in expected[name].items():
            ref = dataset_ref.collection(name).document(rid)
            action = "created" if rid not in actual[name] else ("skipped" if actual[name][rid] == rec else "updated")
            if action == "skipped":
                stats[action] += 1
                continue
            batch.set(ref, rec, merge=False)
            stats[action] += 1; queued += 1
            if queued % 400 == 0:
                batch.commit(); batch = db.batch()
    if queued % 400: batch.commit()

    if args.mode == "sync" and args.delete_stale:
        for name, ids in stale.items():
            for rid in ids:
                dataset_ref.collection(name).document(rid).delete()
                stats["deleted"] += 1

    print("\nWrite result:")
    for k in ("created", "updated", "skipped", "deleted", "failed"):
        print(f"  {k:<8} {stats[k]}")
    verified = verify_after_seed(db, payload)
    if not verified:
        raise SystemExit(3)
    print("\nSeed + post-seed verification: PASS")
    print("datasets/real and users/* were never targeted by this script.")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Deterministically seed/synchronize BharatStandards AI datasets/demo only.")
    p.add_argument("--dataset", default="demo", help="Safety guard; only 'demo' is accepted.")
    p.add_argument("--mode", choices=("merge", "sync"), default="merge")
    p.add_argument("--dry-run", action="store_true", help="Read Firestore and show CREATE/UPDATE/UNCHANGED/STALE without writes.")
    p.add_argument("--delete-stale", action="store_true", help="With --mode sync, explicitly delete stale datasets/demo docs only.")
    p.add_argument("--yes", action="store_true", help="Non-interactive confirmation for DEMO-only writes.")
    p.add_argument("--validate-only", action="store_true", help="Validate JSON without connecting to Firestore.")
    seed(p.parse_args())
