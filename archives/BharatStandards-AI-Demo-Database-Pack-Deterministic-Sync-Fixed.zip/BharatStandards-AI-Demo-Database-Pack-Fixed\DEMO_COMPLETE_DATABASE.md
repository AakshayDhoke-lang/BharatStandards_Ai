# BharatStandards AI — Deterministic DEMO Database Pack

This pack is the shared DEMO knowledge fixture for the canonical BharatStandards AI application. It seeds **only** `datasets/demo/**`; it never targets `datasets/real/**` or `users/**`.

## Record counts

| Collection | Count |
|---|---:|
| categories | 15 |
| products | 19 |
| standards | 19 |
| relationships | 12 |
| certifications | 19 |
| qcos | 3 |
| amendments | 19 |
| sources | 4 |
| submissions | 2 |
| ingestionJobs | 2 |
| auditLogs | 8 |

Operational metadata is additionally written to `datasets/demo/metadata/database`; it is not regulatory evidence.

## Critical canonical mappings

- Hot-Rolled Structural Steel → `STRUCTURAL_STEEL_PLATE` → `IS-2062-2011`
- Reinforcement Steel Bar / TMT Bar → `REINFORCEMENT_STEEL_BAR` → `IS-1786-2008`
- Ordinary Portland Cement → `ORDINARY_PORTLAND_CEMENT` → `IS-269-2015`
- Centrifugal Water Pump → `CENTRIFUGAL_WATER_PUMP` → `IS-6595-P2-2024`
- PVC insulated electrical cable → `ELECTRICAL_CABLE` → `IS-694-2010`
- Rotationally moulded PE water storage tank → `WATER_TANK` → `IS-12701-1996`

The TMT record contains normalized aliases including `tmt`, `tmt bars`, `reinforcement bars`, `deformed bar`, and `rebars`. OPC includes `opc`, `portland cement`, and `ordinary cement`. These are additive schema-compatible aliases; document IDs and record counts remain unchanged.

## Validation and tests

Offline JSON/database validation:

```cmd
python verify_demo_database.py --offline
```

Golden database-level regression tests:

```cmd
python test_demo_database.py
```

Validate the seed payload without connecting to Firestore:

```cmd
python seed_complete_demo_database.py --validate-only
```

## Firestore synchronization

Install the Admin SDK first if needed:

```cmd
python -m pip install firebase-admin
```

Configure Firebase Admin credentials through Application Default Credentials, `FIREBASE_SERVICE_ACCOUNT_PATH`, or the supported service-account environment variables.

Read-only verification of the currently installed Firestore DEMO dataset:

```cmd
python verify_demo_database.py
```

Dry-run synchronization (connects to Firestore, performs no writes):

```cmd
python seed_complete_demo_database.py --mode sync --dry-run
```

Safe merge seed (creates/updates expected DEMO documents, leaves extras untouched):

```cmd
python seed_complete_demo_database.py --mode merge
```

Exact deterministic sync with stale deletion requires explicit opt-in:

```cmd
python seed_complete_demo_database.py --mode sync --delete-stale
```

For CI/non-interactive DEMO-only seeding, add `--yes` after reviewing the target project and dry-run output.

## Safety behavior

The seeder refuses any target other than `demo`. `--delete-stale` is valid only with `--mode sync`, and deletions are limited to extra documents under the known `datasets/demo/<collection>` paths. The script never constructs paths under `datasets/real` or `users`.

After a real seed, the seeder reads Firestore back, verifies collection counts and critical product mappings, and exits non-zero if post-seed verification fails.

## Regulatory-data policy

This is DEMO data. Missing mandatory-certification, QCO, reaffirmation, amendment, or other regulatory facts remain unknown/null/empty unless already established by the pack. The update does not invent BIS facts.
