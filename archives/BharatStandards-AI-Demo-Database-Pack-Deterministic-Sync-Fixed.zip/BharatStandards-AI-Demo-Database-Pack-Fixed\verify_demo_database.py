from __future__ import annotations

import argparse
import sys
from pathlib import Path

from demo_database_validation import COLLECTIONS, CRITICAL_MAPPINGS, load_database, validate_database
from seed_complete_demo_database import DATA_FILE, expected_docs, firebase_project_id, firestore_snapshot, get_firestore_client


def print_offline(report):
    print("BharatStandards AI")
    print("DEMO Database Verification")
    print("=" * 44)
    print("Source: complete_demo_database.json")
    for name in COLLECTIONS:
        print(f"{name:<16} {report['counts'][name]:>4} {'PASS' if not any(e.startswith('COUNT '+name) for e in report['errors']) else 'FAIL'}")
    print("\nCritical mappings:")
    for pid, item in report["criticalMappings"].items():
        print(f"  {pid:<26} {'PASS' if item['pass'] else 'FAIL'} -> {item['actualStandard']}")
    print(f"\nBroken/orphan relationship sources: {len(report['orphanRelationships'])}")
    print(f"Critical alias collisions: {len(report['criticalAliasCollisions'])}")
    print(f"Weak/generic alias collisions: {len(report['weakAliasCollisions'])}")
    if report['errors']:
        print("\nErrors:")
        for e in report['errors']: print("  -", e)
    if report['warnings']:
        print("\nWarnings:")
        for w in report['warnings']: print("  -", w)
    print("\nOverall:", "PASS" if report['ok'] else "FAIL")


def main() -> int:
    ap = argparse.ArgumentParser(description="Read-only verifier for BharatStandards AI DEMO database.")
    ap.add_argument("--offline", action="store_true", help="Validate packaged JSON only; do not connect to Firestore.")
    args = ap.parse_args()
    payload = load_database(DATA_FILE)
    report = validate_database(payload)
    if args.offline:
        print_offline(report)
        return 0 if report['ok'] else 2
    if not report['ok']:
        print_offline(report); return 2

    db = get_firestore_client()
    expected = expected_docs(payload)
    actual, stale = firestore_snapshot(db, expected)
    print("BharatStandards AI")
    print("DEMO Database Verification")
    print("=" * 44)
    print("Firebase Project:", firebase_project_id(db))
    print("Dataset: DEMO")
    ok = True
    for name in COLLECTIONS:
        got, want = len(actual[name]), len(expected[name])
        passed = got == want
        print(f"{name:<16} {got:>4} {'PASS' if passed else f'FAIL expected {want}'}")
        ok = ok and passed
    print("\nCritical mappings:")
    for pid, (family, sid) in CRITICAL_MAPPINGS.items():
        rec = actual['products'].get(pid, {})
        passed = rec.get('productFamily') == family and rec.get('primaryStandardId') == sid
        print(f"  {pid:<26} {'PASS' if passed else 'FAIL'} -> {rec.get('primaryStandardId')}")
        ok = ok and passed
    stale_count = sum(len(v) for v in stale.values())
    print("\nStale records:", stale_count)
    for name, ids in stale.items():
        for rid in ids: print(f"  STALE datasets/demo/{name}/{rid}")
    print("\nCritical alias collisions:", len(report['criticalAliasCollisions']))
    print("Orphan relationships:", len(report['orphanRelationships']))
    ok = ok and not report['criticalAliasCollisions'] and not report['orphanRelationships']
    print("\nOverall:", "PASS" if ok else "FAIL")
    return 0 if ok else 3


if __name__ == '__main__':
    raise SystemExit(main())
