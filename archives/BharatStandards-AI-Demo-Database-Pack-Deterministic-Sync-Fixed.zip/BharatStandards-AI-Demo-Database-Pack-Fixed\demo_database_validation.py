from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

COLLECTIONS = [
    "categories", "products", "standards", "relationships",
    "certifications", "qcos", "amendments", "sources",
    "submissions", "ingestionJobs", "auditLogs",
]
EXPECTED_COUNTS = {
    "categories": 15, "products": 19, "standards": 19, "relationships": 12,
    "certifications": 19, "qcos": 3, "amendments": 19, "sources": 4,
    "submissions": 2, "ingestionJobs": 2, "auditLogs": 8,
}
SUPPORTED_RELATIONSHIP_TYPES = {
    "NORMATIVE_REFERENCE", "TEST_METHOD", "SAFETY", "TERMINOLOGY",
    "INSTALLATION", "RELATED_PRODUCT", "MATERIAL", "SAMPLING",
    "CODE_OF_PRACTICE", "PERFORMANCE", "SAFETY_TEST",
}
CRITICAL_MAPPINGS = {
    "structural-steel-1": ("STRUCTURAL_STEEL_PLATE", "IS-2062-2011"),
    "reinforcement-steel-1": ("REINFORCEMENT_STEEL_BAR", "IS-1786-2008"),
    "cement-concrete-1": ("ORDINARY_PORTLAND_CEMENT", "IS-269-2015"),
    "pumps-mechanical-1": ("CENTRIFUGAL_WATER_PUMP", "IS-6595-P2-2024"),
    "electrical-cables-1": ("ELECTRICAL_CABLE", "IS-694-2010"),
    "water-storage-1": ("WATER_TANK", "IS-12701-1996"),
}
GENERIC_ALIASES = {
    "steel", "water", "product", "equipment", "material", "construction",
    "building", "plastic", "pvc", "cement", "fan", "cable", "pipe", "tank",
}


def normalize(value: str) -> str:
    value = value.casefold().replace("–", "-").replace("—", "-")
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def load_database(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _id_for(collection: str, rec: dict[str, Any]) -> str | None:
    key = {
        "categories": "categoryId", "products": "productId", "standards": "standardId",
        "relationships": "relationshipId", "certifications": "certificationId",
        "qcos": "qcoId", "amendments": "versionRecordId", "sources": "sourceId",
        "submissions": "submissionId", "ingestionJobs": "jobId",
    }.get(collection)
    return str(rec.get(key)) if key and rec.get(key) else None


def validate_database(data: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []

    # Counts and duplicate IDs.
    counts = {name: len(data.get(name, [])) for name in COLLECTIONS}
    for name, expected in EXPECTED_COUNTS.items():
        if counts.get(name) != expected:
            errors.append(f"COUNT {name}: expected {expected}, got {counts.get(name)}")

    ids_by_collection: dict[str, set[str]] = {}
    for name in COLLECTIONS:
        seen: set[str] = set()
        for rec in data.get(name, []):
            rid = _id_for(name, rec)
            if rid:
                if rid in seen:
                    errors.append(f"DUPLICATE ID {name}/{rid}")
                seen.add(rid)
            if rec.get("dataMode") not in (None, "DEMO"):
                errors.append(f"NON-DEMO record in {name}: {rid or '<no id>'}")
        ids_by_collection[name] = seen

    categories = {r.get("categoryId"): r for r in data.get("categories", [])}
    standards = {r.get("standardId"): r for r in data.get("standards", [])}
    products = {r.get("productId"): r for r in data.get("products", [])}

    # Product integrity.
    family_to_primary: dict[str, set[str]] = defaultdict(set)
    for pid, p in products.items():
        if not pid:
            errors.append("PRODUCT missing productId")
            continue
        required = ["productName", "categoryId", "category", "domain", "productFamily", "primaryStandardId"]
        for field in required:
            if not p.get(field):
                errors.append(f"PRODUCT {pid} missing {field}")
        cid = p.get("categoryId")
        if cid not in categories:
            errors.append(f"PRODUCT {pid} references missing category {cid}")
        sid = p.get("primaryStandardId")
        if sid not in standards:
            errors.append(f"PRODUCT {pid} references missing primary standard {sid}")
        else:
            sf = standards[sid].get("productFamily")
            if p.get("productFamily") and sf and p.get("productFamily") != sf:
                errors.append(f"PRODUCT {pid} family {p.get('productFamily')} != standard {sid} family {sf}")
        for linked in p.get("linkedStandards", []) or []:
            if linked not in standards:
                errors.append(f"PRODUCT {pid} linked standard missing: {linked}")
        family_to_primary[str(p.get("productFamily"))].add(str(sid))
        aliases = [normalize(str(a)) for a in (p.get("aliases") or []) if str(a).strip()]
        if len(aliases) != len(set(aliases)):
            warnings.append(f"PRODUCT {pid} has duplicate normalized aliases")

    # Detect conflicting family->primary mappings.
    for family, primary_ids in family_to_primary.items():
        if family and family != "None" and len(primary_ids) > 1:
            warnings.append(f"PRODUCT FAMILY {family} maps to multiple primaries: {sorted(primary_ids)}")

    # Critical mappings and alias requirements.
    for pid, (family, sid) in CRITICAL_MAPPINGS.items():
        p = products.get(pid)
        if not p:
            errors.append(f"CRITICAL product missing: {pid}")
            continue
        if p.get("productFamily") != family:
            errors.append(f"CRITICAL {pid} family expected {family}, got {p.get('productFamily')}")
        if p.get("primaryStandardId") != sid:
            errors.append(f"CRITICAL {pid} primary expected {sid}, got {p.get('primaryStandardId')}")

    required_aliases = {
        "structural-steel-1": {"structural steel", "hot rolled structural steel", "structural steel plate", "steel plate"},
        "reinforcement-steel-1": {"reinforcement steel bar", "reinforcing bar", "reinforcement bar", "reinforcement bars", "steel reinforcement bar", "tmt", "tmt bar", "tmt bars", "deformed bar", "deformed steel bar", "high strength deformed bar", "high strength deformed reinforcement bar", "rebar", "rebars"},
        "cement-concrete-1": {"ordinary portland cement", "opc", "opc cement", "portland cement", "ordinary cement"},
        "pumps-mechanical-1": {"centrifugal water pump", "centrifugal pump", "horizontal centrifugal pump", "water pump", "water circulation pump"},
    }
    for pid, required in required_aliases.items():
        actual = {normalize(str(a)) for a in products[pid].get("aliases", [])}
        missing = {normalize(a) for a in required} - actual
        if missing:
            errors.append(f"PRODUCT {pid} missing required aliases: {sorted(missing)}")

    # Alias collision report across incompatible families.
    alias_map: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for pid, p in products.items():
        family = str(p.get("productFamily") or "")
        for alias in p.get("aliases", []) or []:
            n = normalize(str(alias))
            if n:
                alias_map[n].append((pid, family))
    critical_collisions: list[dict[str, Any]] = []
    weak_collisions: list[dict[str, Any]] = []
    for alias, owners in sorted(alias_map.items()):
        families = {f for _, f in owners}
        if len(families) > 1:
            item = {"alias": alias, "owners": owners}
            if alias in GENERIC_ALIASES or len(alias.split()) <= 1:
                weak_collisions.append(item)
            else:
                critical_collisions.append(item)
                errors.append(f"CRITICAL alias collision '{alias}' across {sorted(families)}")

    # Standard integrity.
    for sid, s in standards.items():
        if not sid:
            errors.append("STANDARD missing standardId")
            continue
        if not (s.get("isNumber") or s.get("identity", {}).get("designation")):
            errors.append(f"STANDARD {sid} missing isNumber/designation")
        if not s.get("title"):
            errors.append(f"STANDARD {sid} missing title")
        if not s.get("productFamily"):
            errors.append(f"STANDARD {sid} missing productFamily")

    # Relationships: source must be one of the 19 standards. Target is often an external allied IS reference.
    rel_ids: set[str] = set()
    rel_keys: set[tuple[str, str, str]] = set()
    orphan_relationships: list[str] = []
    for r in data.get("relationships", []):
        rid = str(r.get("relationshipId") or "")
        if rid in rel_ids:
            errors.append(f"DUPLICATE relationship {rid}")
        rel_ids.add(rid)
        source = r.get("fromStandardId") or r.get("sourceStandardId")
        if source not in standards:
            orphan_relationships.append(rid)
            errors.append(f"RELATIONSHIP {rid} source standard missing: {source}")
        rtype = str(r.get("relationshipType") or r.get("relationship") or "")
        if rtype not in SUPPORTED_RELATIONSHIP_TYPES:
            errors.append(f"RELATIONSHIP {rid} unsupported type: {rtype}")
        target = str(r.get("toStandardId") or r.get("toStandard") or r.get("targetStandardId") or r.get("targetStandard") or "")
        if not target:
            errors.append(f"RELATIONSHIP {rid} missing target reference")
        if source and target and normalize(str(source)) == normalize(target):
            errors.append(f"RELATIONSHIP {rid} self-link")
        key = (str(source), normalize(target), rtype)
        if key in rel_keys:
            errors.append(f"DUPLICATE relationship semantic key: {key}")
        rel_keys.add(key)

    # Certification, QCO, amendment references where explicit standardId exists.
    for cname, idfield in (("certifications", "certificationId"), ("qcos", "qcoId"), ("amendments", "versionRecordId")):
        for rec in data.get(cname, []):
            rid = rec.get(idfield)
            sid = rec.get("standardId")
            if sid and sid not in standards:
                errors.append(f"{cname.upper()} {rid} references missing standard {sid}")
            pid = rec.get("productId")
            if pid and pid not in products:
                errors.append(f"{cname.upper()} {rid} references missing product {pid}")

    return {
        "ok": not errors,
        "counts": counts,
        "errors": errors,
        "warnings": warnings,
        "criticalMappings": {
            pid: {
                "expectedFamily": family,
                "expectedStandard": sid,
                "actualFamily": products.get(pid, {}).get("productFamily"),
                "actualStandard": products.get(pid, {}).get("primaryStandardId"),
                "pass": bool(products.get(pid)) and products[pid].get("productFamily") == family and products[pid].get("primaryStandardId") == sid,
            }
            for pid, (family, sid) in CRITICAL_MAPPINGS.items()
        },
        "criticalAliasCollisions": critical_collisions,
        "weakAliasCollisions": weak_collisions,
        "orphanRelationships": orphan_relationships,
    }
