from __future__ import annotations

from demo_database_validation import CRITICAL_MAPPINGS, load_database, normalize, validate_database

DATA = load_database('complete_demo_database.json')
PRODUCTS = {p['productId']: p for p in DATA['products']}
STANDARDS = {s['standardId']: s for s in DATA['standards']}

CASES = [
    ('Hot-Rolled Structural Steel', 'structural-steel-1', 'STRUCTURAL_STEEL_PLATE', 'IS-2062-2011'),
    ('High-Strength Deformed Reinforcement Bars / TMT', 'reinforcement-steel-1', 'REINFORCEMENT_STEEL_BAR', 'IS-1786-2008'),
    ('Ordinary Portland Cement / OPC', 'cement-concrete-1', 'ORDINARY_PORTLAND_CEMENT', 'IS-269-2015'),
    ('Centrifugal Water Pump for clean-water transfer', 'pumps-mechanical-1', 'CENTRIFUGAL_WATER_PUMP', 'IS-6595-P2-2024'),
    ('PVC insulated copper electrical cable up to 1100 V', 'electrical-cables-1', 'ELECTRICAL_CABLE', 'IS-694-2010'),
    ('Rotationally moulded PE water storage tank', 'water-storage-1', 'WATER_TANK', 'IS-12701-1996'),
]

REQUIRED_TERMS = {
    'reinforcement-steel-1': ['reinforcement steel bar','reinforcing bar','reinforcement bar','reinforcement bars','steel reinforcement bar','tmt','tmt bar','tmt bars','deformed bar','deformed steel bar','high strength deformed bar','high-strength deformed reinforcement bar','rebar','rebars'],
    'cement-concrete-1': ['ordinary portland cement','opc','opc cement','portland cement','ordinary cement'],
    'pumps-mechanical-1': ['centrifugal water pump','centrifugal pump','horizontal centrifugal pump','water pump','water circulation pump'],
}


def has_alias(pid: str, term: str) -> bool:
    aliases = {normalize(a) for a in PRODUCTS[pid].get('aliases', [])}
    return normalize(term) in aliases


def main() -> int:
    report = validate_database(DATA)
    assert report['ok'], report['errors']
    for label, pid, family, sid in CASES:
        p = PRODUCTS[pid]
        assert p['productFamily'] == family, (label, p['productFamily'], family)
        assert p['primaryStandardId'] == sid, (label, p['primaryStandardId'], sid)
        assert sid in STANDARDS
        assert STANDARDS[sid]['productFamily'] == family
        print(f'[PASS] {label} -> {family} -> {sid}')
    for pid, terms in REQUIRED_TERMS.items():
        for term in terms:
            assert has_alias(pid, term), (pid, term)
    # Explicit anti-confusion invariants requested by the pasted specification.
    assert PRODUCTS['reinforcement-steel-1']['primaryStandardId'] != 'IS-2062-2011'
    assert PRODUCTS['pumps-mechanical-1']['primaryStandardId'] not in {'IS-12701-1996','IS-10500-2012','IS-4985-2021'}
    print('[PASS] TMT/Reinforcement does not map to structural steel')
    print('[PASS] Centrifugal pump does not map to tank/drinking-water/pipe standards')
    print('[PASS] Critical alias collisions:', len(report['criticalAliasCollisions']))
    print('GOLDEN DATABASE REGRESSION: PASS')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
